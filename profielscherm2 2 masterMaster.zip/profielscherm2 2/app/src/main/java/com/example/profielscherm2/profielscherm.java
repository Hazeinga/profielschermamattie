package com.example.profielscherm2;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class profielscherm extends AppCompatActivity {
    private Button ebtnBonusknop;
    private Button ebtnAfspraken;
    private Button ebtnContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profielscherm);


        ebtnBonusknop = findViewById(R.id.btnBonusknop);
        ebtnAfspraken = findViewById(R.id.btnAfspraken);
        ebtnContact = findViewById(R.id.btnContact);

        ebtnBonusknop.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent int1 = new Intent(profielscherm.this, bonusscherm.class);
                startActivity(int1);


            }
        });

        ebtnAfspraken.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent int2 = new Intent(profielscherm.this, afsprakenscherm.class);
                startActivity(int2);


            }
        });

        ebtnContact.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {


                Intent int3 = new Intent(profielscherm.this, contactscherm.class);
                startActivity(int3);

            }

        });

    }
}

        

    


    


















package com.example.profielscherm2;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class afsprakenscherm extends AppCompatActivity {
    private Button ebtnprofielknop;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.afsprakenscherm);


        ebtnprofielknop = (Button) findViewById(R.id.btnprofielknop);
        ebtnprofielknop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBonusscherm();

            }
        });


    }

    public void openBonusscherm() {

        Intent intent = new Intent(this, profielscherm.class);
        startActivity(intent);


    }

}

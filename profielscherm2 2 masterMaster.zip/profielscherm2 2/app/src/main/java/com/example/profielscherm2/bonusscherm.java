package com.example.profielscherm2;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class bonusscherm extends AppCompatActivity {
    private Button ebtnprofielknop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bonusscherm);


        ebtnprofielknop = (Button) findViewById(R.id.btnprofielknop);
        ebtnprofielknop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBonusscherm();

            }
        });

    }
    public void openBonusscherm() {

        Intent intent = new Intent(this, profielscherm.class );
        startActivity(intent);
    }
}